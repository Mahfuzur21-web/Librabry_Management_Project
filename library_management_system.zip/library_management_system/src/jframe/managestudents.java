/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package jframe;









import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.text.MessageFormat;

/**
 *
 * @author MAHFUZUR RAHMAN
 */
public class managestudents extends javax.swing.JFrame {

    /**
     * Creates new form managebooks
     */
    public managestudents() {
        initComponents();
        
        setstudentdetails();
    }
    
    
    //set data into the table
    
    String student_name,department_name;
    int student_id,roll;
    DefaultTableModel model;
    
    public void setstudentdetails(){
    
    try{
        
    Connection con = DBConnection.getConnection();
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery("select * from student_details");
    
    while(rs.next()){
        
        int studentid = rs.getInt("student_id");
        String studentname = rs.getString("student_name");
        int roll = rs.getInt("roll");
        String department = rs.getString("department");
        
        Object[] obj = {studentid,studentname,roll,department};
        
        model = (DefaultTableModel)tbl_studentsdetails.getModel();
        model.addRow(obj);
    }
    
    }catch(SQLException e){
    JOptionPane.showMessageDialog(null,e);
    }

    }

    
    //Add book details into database
    
    public boolean addstudent(){
        boolean isadd = false;
        
    student_id = Integer.parseInt(txt_studentid.getText());
    student_name = txt_studentname.getText();
    roll = Integer.parseInt(txt_roll.getText());
    department_name = cbx_department.getSelectedItem().toString();
    
    
    
    try{
    Connection con = DBConnection.getConnection();
    String sql = "insert into student_details values(?,?,?,?)";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1, student_id);
    pst.setString(2, student_name);
    pst.setInt(3, roll);
    pst.setString(4, department_name);
    
    int rowc = pst.executeUpdate();
    
    if(rowc > 0){
    
       isadd = true;  
    }
    else{
    isadd = false;
    }
    
    }catch(SQLException e){
    JOptionPane.showMessageDialog(null,e);
    }
    
    return isadd; 
    }
    
    
    
    //Update book into database
    
    
    public boolean updatestudent(){
    
            boolean isupdated = false;
        
    student_id = Integer.parseInt(txt_studentid.getText());
    student_name = txt_studentname.getText();
    roll = Integer.parseInt(txt_roll.getText());
    department_name = cbx_department.getSelectedItem().toString();
    
    try{
    
    
    Connection con = DBConnection.getConnection();
    String sql = "update student_details set student_name=?,roll=?,department=? where student_id=? ";
    
    PreparedStatement pst = con.prepareStatement(sql);
    
    pst.setString(1, student_name);
    pst.setInt(2, roll);
    pst.setString(3, department_name);
     pst.setInt(4, student_id);
     
     
     int rowc = pst.executeUpdate();
     
     if(rowc > 0){
     isupdated = true;
     }
     else{
     isupdated = false;
     }
    
    
    }catch(SQLException e){
    JOptionPane.showMessageDialog(null,e);
    
    }
    return isupdated;
    }
    
    
    
    //Delete book into Database
    
    public boolean deletestudent(){
                boolean isdeleted = false;
        
    student_id = Integer.parseInt(txt_studentid.getText());
    
    try{
    
    Connection con = DBConnection.getConnection();
        String sql = "delete from student_details where student_id=? ";
    
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1, student_id);
    
    int rowc = pst.executeUpdate();
    
    if(rowc > 0){
    isdeleted = true;
    
    }
    else{
    isdeleted = false;
    
    
    }
    
    
    }catch(SQLException e){
    JOptionPane.showMessageDialog(null,e);
    }
    
    
    return isdeleted;
    }
    
    //serach from database
    
    
    public void searchd(){
        
        try{
        
            Connection con = DBConnection.getConnection();
    String sql = "SELECT * FROM student_details where student_id=? ";
    PreparedStatement pst = con.prepareStatement(sql);
    int id = Integer.parseInt(txt_studentid.getText());
            pst.setInt(1, id);
             ResultSet rs = pst.executeQuery();
   
            if(rs.next()){
                String add1 = rs.getString("student_id");
                txt_studentid.setText(add1);
                String add2 = rs.getString("student_name");
                txt_studentname.setText(add2);
                String add3 = rs.getString("roll");
                txt_roll.setText(add3);
                String add4 = rs.getString("department");
                cbx_department.setSelectedItem(add4);

            }
            else
            {
                JOptionPane.showInternalMessageDialog(this,"Please try again,Record Not Found");
            }
        
        }catch(NumberFormatException | SQLException e){
        JOptionPane.showMessageDialog(null,"Please Enter student Id");
        }
        

    
    }
    
    //clear table 
    
    public void cleartbl(){
  DefaultTableModel model =   (DefaultTableModel)tbl_studentsdetails.getModel();
    model.setRowCount(0);
    
    }
    
    
    
    //Record Print
    
    public void printrecord(){
    
    String h = "Student Record";
    MessageFormat header = new MessageFormat(h);

    MessageFormat footer = new MessageFormat("S.M.Rahman Library Management System");
    
    try{
    
    tbl_studentsdetails.print(JTable.PrintMode.FIT_WIDTH,header,footer);
    
    }catch(PrinterException e){
    JOptionPane.showMessageDialog(null,"Can Not Print"+e.getMessage());
    }
    
    
    
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_studentid = new app.bolivia.swing.JCTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_studentname = new app.bolivia.swing.JCTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt_roll = new app.bolivia.swing.JCTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnsearch = new rojerusan.RSMaterialButtonCircle();
        btnadd = new rojerusan.RSMaterialButtonCircle();
        btnupdate = new rojerusan.RSMaterialButtonCircle();
        btndelete = new rojerusan.RSMaterialButtonCircle();
        rSMaterialButtonCircle2 = new rojerusan.RSMaterialButtonCircle();
        cbx_department = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        rSButtonHover1 = new rojeru_san.complementos.RSButtonHover();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_studentsdetails = new rojeru_san.complementos.RSTableMetro();
        jLabel10 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        rSButtonHover2 = new rojeru_san.complementos.RSButtonHover();
        btn_print = new rojeru_san.complementos.RSButtonHover();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 102, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel1.setText("Back");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 120, 50));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 120, 50));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Enter Student Id");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 140, 40));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Contact_26px.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 70, 50));

        txt_studentid.setBackground(new java.awt.Color(0, 102, 102));
        txt_studentid.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_studentid.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        txt_studentid.setPlaceholder("Enter Student Id");
        jPanel1.add(txt_studentid, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 130, 210, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Enter Student Name");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 160, 40));

        txt_studentname.setBackground(new java.awt.Color(0, 102, 102));
        txt_studentname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_studentname.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        txt_studentname.setPlaceholder("Enter Student Name");
        jPanel1.add(txt_studentname, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, 330, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Moleskine_26px.png"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 70, 50));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Collaborator_Male_26px.png"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 70, 50));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Roll");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 350, 140, 40));

        txt_roll.setBackground(new java.awt.Color(0, 102, 102));
        txt_roll.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_roll.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        txt_roll.setPlaceholder("Enter Student Roll Number");
        jPanel1.add(txt_roll, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 400, 330, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Unit_26px.png"))); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 530, 60, 50));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Department");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 480, 140, 40));

        btnsearch.setBackground(new java.awt.Color(204, 204, 255));
        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });
        jPanel1.add(btnsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 120, -1, 60));

        btnadd.setText("ADD");
        btnadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaddActionPerformed(evt);
            }
        });
        jPanel1.add(btnadd, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 600, -1, 60));

        btnupdate.setText("UPDATE");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });
        jPanel1.add(btnupdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 600, -1, 60));

        btndelete.setText("DELETE");
        btndelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteActionPerformed(evt);
            }
        });
        jPanel1.add(btndelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 600, -1, 60));

        rSMaterialButtonCircle2.setBackground(new java.awt.Color(204, 0, 51));
        rSMaterialButtonCircle2.setText("CLEAR");
        rSMaterialButtonCircle2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle2ActionPerformed(evt);
            }
        });
        jPanel1.add(rSMaterialButtonCircle2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, -1, 60));

        cbx_department.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        cbx_department.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CSE", "CSE-Ev.", "ECE", "ECE-Ev.", "LLB", "LLB-Ev.", "LLM", "LLM-Ev." }));
        jPanel1.add(cbx_department, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 540, 330, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, 730));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rSButtonHover1.setBackground(new java.awt.Color(102, 0, 102));
        rSButtonHover1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rSButtonHover1.setText("-");
        rSButtonHover1.setColorHover(new java.awt.Color(255, 0, 0));
        rSButtonHover1.setColorText(new java.awt.Color(0, 0, 0));
        rSButtonHover1.setFont(new java.awt.Font("Verdana", 1, 35)); // NOI18N
        rSButtonHover1.setInheritsPopupMenu(true);
        rSButtonHover1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSButtonHover1MouseClicked(evt);
            }
        });
        rSButtonHover1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonHover1ActionPerformed(evt);
            }
        });
        jPanel3.add(rSButtonHover1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 0, 50, 30));

        tbl_studentsdetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Id", "Students Name", "Roll", "Department"
            }
        ));
        tbl_studentsdetails.setColorSelBackgound(new java.awt.Color(0, 102, 102));
        tbl_studentsdetails.setFont(new java.awt.Font("Yu Gothic Light", 1, 25)); // NOI18N
        tbl_studentsdetails.setFuenteFilas(new java.awt.Font("Times New Roman", 0, 15)); // NOI18N
        tbl_studentsdetails.setFuenteFilasSelect(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        tbl_studentsdetails.setFuenteHead(new java.awt.Font("Yu Gothic UI Semibold", 1, 25)); // NOI18N
        tbl_studentsdetails.setRowHeight(35);
        tbl_studentsdetails.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_studentsdetailsMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_studentsdetails);
        if (tbl_studentsdetails.getColumnModel().getColumnCount() > 0) {
            tbl_studentsdetails.getColumnModel().getColumn(1).setResizable(false);
            tbl_studentsdetails.getColumnModel().getColumn(3).setResizable(false);
        }

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 780, 330));

        jLabel10.setFont(new java.awt.Font("Verdana", 1, 30)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 0, 102));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Student_Male_100px.png"))); // NOI18N
        jLabel10.setText("  Manage Students");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 430, 100));

        jPanel4.setBackground(new java.awt.Color(255, 0, 102));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 120, 500, 5));

        rSButtonHover2.setBackground(new java.awt.Color(0, 102, 102));
        rSButtonHover2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rSButtonHover2.setText("X");
        rSButtonHover2.setColorHover(new java.awt.Color(255, 0, 0));
        rSButtonHover2.setColorText(new java.awt.Color(0, 0, 0));
        rSButtonHover2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 25)); // NOI18N
        rSButtonHover2.setInheritsPopupMenu(true);
        rSButtonHover2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSButtonHover2MouseClicked(evt);
            }
        });
        rSButtonHover2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonHover2ActionPerformed(evt);
            }
        });
        jPanel3.add(rSButtonHover2, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 0, 50, 30));

        btn_print.setBackground(new java.awt.Color(255, 0, 255));
        btn_print.setText("Print");
        btn_print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_printActionPerformed(evt);
            }
        });
        jPanel3.add(btn_print, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 130, 80, 30));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, 820, 730));

        setSize(new java.awt.Dimension(1283, 731));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        homepage hp = new homepage();
        hp.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel1MouseClicked

    private void rSButtonHover1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSButtonHover1MouseClicked
        
    }//GEN-LAST:event_rSButtonHover1MouseClicked

    private void rSButtonHover1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonHover1ActionPerformed
        this.setExtendedState(managestudents.ICONIFIED);
    }//GEN-LAST:event_rSButtonHover1ActionPerformed

    private void tbl_studentsdetailsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_studentsdetailsMouseClicked
        int rowm = tbl_studentsdetails.getSelectedRow();
        TableModel model = tbl_studentsdetails.getModel();
        
        txt_studentid.setText(model.getValueAt(rowm,0).toString());
        txt_studentname.setText(model.getValueAt(rowm,1).toString());
        txt_roll.setText(model.getValueAt(rowm,2).toString());
        cbx_department.setSelectedItem(model.getValueAt(rowm,3).toString());
    }//GEN-LAST:event_tbl_studentsdetailsMouseClicked

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
searchd();
    }//GEN-LAST:event_btnsearchActionPerformed

    private void btndeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteActionPerformed
        if(deletestudent()==true){
            JOptionPane.showMessageDialog(this,"Student Deleted Successfully");
            cleartbl();
            setstudentdetails();

        }
        else{
            JOptionPane.showMessageDialog(this,"Student Deletion Failed");
        }
    }//GEN-LAST:event_btndeleteActionPerformed

    private void rSMaterialButtonCircle2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle2ActionPerformed
        txt_studentid.setText("");
        txt_studentname.setText("");
        txt_roll.setText("");
        cbx_department.setToolTipText("");
                
                
                
    }//GEN-LAST:event_rSMaterialButtonCircle2ActionPerformed

    private void btnaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaddActionPerformed
        if(addstudent()==true){
            JOptionPane.showMessageDialog(this,"Student Added Successfully");
            cleartbl();
            setstudentdetails();

        }
        else{
            JOptionPane.showMessageDialog(this,"Student Addition Failed");
        }
    }//GEN-LAST:event_btnaddActionPerformed

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        if(updatestudent()==true){
            JOptionPane.showMessageDialog(this,"Student Updated Successfully");
            cleartbl();
            setstudentdetails();

        }
        else{
            JOptionPane.showMessageDialog(this,"Book Updation Failed");
        }
    }//GEN-LAST:event_btnupdateActionPerformed

    private void rSButtonHover2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSButtonHover2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rSButtonHover2MouseClicked

    private void rSButtonHover2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonHover2ActionPerformed
               int y_n = JOptionPane.showConfirmDialog(this,"Do you Want To Close ? ","WARNING",JOptionPane.YES_NO_OPTION);
        
        if(y_n ==JOptionPane.YES_OPTION){
        System.exit(0);
        
        }
    }//GEN-LAST:event_rSButtonHover2ActionPerformed

    private void btn_printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_printActionPerformed
       printrecord();
    }//GEN-LAST:event_btn_printActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])  {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(managestudents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(managestudents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(managestudents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(managestudents.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new managestudents().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private rojeru_san.complementos.RSButtonHover btn_print;
    private rojerusan.RSMaterialButtonCircle btnadd;
    private rojerusan.RSMaterialButtonCircle btndelete;
    private rojerusan.RSMaterialButtonCircle btnsearch;
    private rojerusan.RSMaterialButtonCircle btnupdate;
    private javax.swing.JComboBox<String> cbx_department;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane3;
    private rojeru_san.complementos.RSButtonHover rSButtonHover1;
    private rojeru_san.complementos.RSButtonHover rSButtonHover2;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle2;
    private rojeru_san.complementos.RSTableMetro tbl_studentsdetails;
    private app.bolivia.swing.JCTextField txt_roll;
    private app.bolivia.swing.JCTextField txt_studentid;
    private app.bolivia.swing.JCTextField txt_studentname;
    // End of variables declaration//GEN-END:variables
}
