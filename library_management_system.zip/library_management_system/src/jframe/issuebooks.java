/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package jframe;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.util.Date;

/**
 *
 * @author MAHFUZUR RAHMAN
 */
public class issuebooks extends javax.swing.JFrame {

    /**
     * Creates new form issuebooks
     */
    public issuebooks() {
        initComponents();
        issuedatedisplay();
    }

    //Display Current Date on issue Date
    
    public void issuedatedisplay(){
    
        Long d = System.currentTimeMillis();
        
    java.sql.Date tdate = new java.sql.Date(d);
    date_issue.setDate(tdate);
    date_issue.setEnabled(false);
    
    }
    
    
    //Display Book details by enter book id from database
    
    public void getbookdetails(){
    
    int bookid = Integer.parseInt(txt_bookid.getText());
    
    try{
        Connection con = DBConnection.getConnection();
        String sql = "select * from books_dtails where book_id=?";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setInt(1, bookid);
        ResultSet rs = pst.executeQuery();
        
        if(rs.next()){
        
        lbl_bookid.setText(rs.getString("book_id"));
        lbl_bookname.setText(rs.getString("book_name"));
        lbl_authorname.setText(rs.getString("author_name"));
        lbl_quantity.setText(rs.getString("quantity"));
        lbl_nullbookid.setText("");
        
        }
        else{
            
        lbl_nullbookid.setText("Invalid Book Id");
        
        }
        
    
    
    
    }catch(SQLException e){
    JOptionPane.showMessageDialog(null,e);
    
    }
    
    
    }
    
    
    
    
    
    //Display Student details by enter book id from database
    
    public void getstudentdetails(){
    
    int bookid = Integer.parseInt(txt_studentid.getText());
    
    try{
        Connection con = DBConnection.getConnection();
        String sql = "select * from student_details where student_id=?";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setInt(1, bookid);
        ResultSet rs = pst.executeQuery();
        
        if(rs.next()){
        
        lbl_studentid.setText(rs.getString("student_id"));
        lbl_studentname.setText(rs.getString("student_name"));
        lbl_roll.setText(rs.getString("roll"));
        lbl_department.setText(rs.getString("department"));
        lbl_nullstudentid.setText("");
        }
        else{
            
        lbl_nullstudentid.setText("Invalid Student Id");
            
        }
    
    
    
    }catch(SQLException e){
    JOptionPane.showMessageDialog(null,e);
    
    }
    
    
    }
    
    
    //insert issue book details into database
    
    
    public boolean issuebook(){
        
        boolean issued = false;
    
    int bookid = Integer.parseInt(lbl_bookid.getText());
    int studentid = Integer.parseInt(lbl_studentid.getText());
    String bookname = lbl_bookname.getText();
    String studentname = lbl_studentname.getText();
    

    Date sdate = date_issue.getDate();
    Date duedate = date_due.getDate();
    
    Long sd = sdate.getTime();
    Long dd = duedate.getTime();
    
    java.sql.Date issuedates = new java.sql.Date(sd);
    java.sql.Date duedates = new java.sql.Date(dd);
    
    
    try{
    
    Connection con = DBConnection.getConnection();
    String sql = "insert into issue_book_details (book_id,book_name,student_id,student_name,issue_date,due_date,status) values(?,?,?,?,?,?,?)";
    PreparedStatement pst = con.prepareStatement(sql);
    
    
    pst.setInt(1, bookid);
    pst.setString(2, bookname);
    pst.setInt(3, studentid);
    pst.setString(4, studentname);
    pst.setDate(5, issuedates);
    pst.setDate(6, duedates);
    pst.setString(7, "Pending");
    
    int rowc = pst.executeUpdate();
    
    if(rowc > 0){
    
    issued = true;
    }
    else{
    issued = false;
    }
    
    
    }catch(SQLException e){
    e.printStackTrace();
    
    }
    
    return issued;
    
    }
    
    
    
    
    //updating book count
    
    public void updatebookcount(){
    
    int bookid = Integer.parseInt(lbl_bookid.getText());
    
    try{
        Connection con = DBConnection.getConnection();
        String sql = "update books_dtails set quantity = quantity-1 where book_id = ?";
        PreparedStatement pst = con.prepareStatement(sql);
        
        pst.setInt(1,bookid );
        
       int rowc =  pst.executeUpdate();
       
       if(rowc > 0){
    JOptionPane.showMessageDialog(this,"Book Quantity Updated");
    
    int value = Integer.parseInt(lbl_quantity.getText());
    lbl_quantity.setText(Integer.toString(value-1));
    
    
    }
    else{
    JOptionPane.showMessageDialog(this,"Can't update the Book Quantity");
    }
    
    }catch(Exception e){
    e.printStackTrace();
    }
    }
    
    
    
    //cheak same person same book issue duplication and It's validation
    
    
    public boolean issuecheak(){
     boolean isissued = false;
    
     int bookid = Integer.parseInt(lbl_bookid.getText());
    int studentid = Integer.parseInt(lbl_studentid.getText());
    
    
    try{
        Connection con = DBConnection.getConnection();
        String sql = "select * from issue_book_details where book_id = ? and student_id = ? and status = ?";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setInt(1,bookid );
        pst.setInt(2,studentid );
        pst.setString(3, "Pending");
        
        ResultSet rs = pst.executeQuery();
        
        if(rs.next()){
        isissued = true;        
        }
        else{
        isissued = false;
        }
    
    }catch(SQLException e){
    e.printStackTrace();
    
    }
     
     
    
    
     
    return isissued; 
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel_main = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lbl_quantity = new javax.swing.JLabel();
        lbl_authorname = new javax.swing.JLabel();
        lbl_bookname = new javax.swing.JLabel();
        lbl_bookid = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lbl_nullbookid = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        lbl_department = new javax.swing.JLabel();
        lbl_roll = new javax.swing.JLabel();
        lbl_studentname = new javax.swing.JLabel();
        lbl_studentid = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        lbl_nullstudentid = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        rSButtonHover1 = new rojeru_san.complementos.RSButtonHover();
        jLabel14 = new javax.swing.JLabel();
        txt_bookid = new app.bolivia.swing.JCTextField();
        txt_studentid = new app.bolivia.swing.JCTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        rSMaterialButtonCircle1 = new rojerusan.RSMaterialButtonCircle();
        rSButtonHover2 = new rojeru_san.complementos.RSButtonHover();
        date_due = new com.toedter.calendar.JDateChooser();
        date_issue = new com.toedter.calendar.JDateChooser();
        rSButtonHover3 = new rojeru_san.complementos.RSButtonHover();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel_main.setBackground(new java.awt.Color(255, 255, 255));
        panel_main.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(102, 0, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 102, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel1.setText("Back");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 110, 50));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 120, 50));

        jLabel10.setFont(new java.awt.Font("Verdana", 1, 30)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Literature_100px_1.png"))); // NOI18N
        jLabel10.setText("   Book Details");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 400, 100));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 420, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, 420, 5));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Book Id :");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 70, 40));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Book Name :");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 100, 40));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Author Name :");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, 110, 40));

        lbl_quantity.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        lbl_quantity.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(lbl_quantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 520, 250, 40));

        lbl_authorname.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        lbl_authorname.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(lbl_authorname, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 420, 260, 40));

        lbl_bookname.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        lbl_bookname.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(lbl_bookname, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 330, 260, 40));

        lbl_bookid.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        lbl_bookid.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(lbl_bookid, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 250, 250, 40));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Quantity :");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, 80, 40));

        lbl_nullbookid.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        lbl_nullbookid.setForeground(new java.awt.Color(255, 255, 0));
        jPanel1.add(lbl_nullbookid, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 630, 240, 40));

        panel_main.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 730));

        jPanel3.setBackground(new java.awt.Color(153, 0, 153));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setFont(new java.awt.Font("Verdana", 1, 30)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Student_Registration_100px_2.png"))); // NOI18N
        jLabel13.setText("   Student Details");
        jPanel3.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 400, 100));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 420, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        jPanel3.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, 420, 5));

        jLabel15.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Student Name :");
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 330, 150, 40));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Roll :");
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, 110, 40));

        jLabel17.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Department :");
        jPanel3.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 520, 110, 40));

        lbl_department.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        lbl_department.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(lbl_department, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 520, 230, 40));

        lbl_roll.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        lbl_roll.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(lbl_roll, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 420, 230, 40));

        lbl_studentname.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        lbl_studentname.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(lbl_studentname, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 330, 230, 40));

        lbl_studentid.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        lbl_studentid.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.add(lbl_studentid, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 250, 220, 40));

        jLabel18.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Student Id :");
        jPanel3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, 110, 40));

        lbl_nullstudentid.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        lbl_nullstudentid.setForeground(new java.awt.Color(255, 255, 0));
        jPanel3.add(lbl_nullstudentid, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 620, 240, 40));

        panel_main.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 0, -1, 730));

        jPanel7.setBackground(new java.awt.Color(255, 51, 0));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 420, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        panel_main.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 180, -1, -1));

        jLabel19.setBackground(new java.awt.Color(255, 255, 255));
        jLabel19.setFont(new java.awt.Font("Verdana", 1, 30)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 51, 0));
        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Books_52px_1.png"))); // NOI18N
        jLabel19.setText("   Issue Books");
        panel_main.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 80, 360, 80));

        rSButtonHover1.setBackground(new java.awt.Color(0, 102, 102));
        rSButtonHover1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rSButtonHover1.setText("X");
        rSButtonHover1.setColorHover(new java.awt.Color(255, 0, 0));
        rSButtonHover1.setColorText(new java.awt.Color(0, 0, 0));
        rSButtonHover1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 25)); // NOI18N
        rSButtonHover1.setInheritsPopupMenu(true);
        rSButtonHover1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSButtonHover1MouseClicked(evt);
            }
        });
        rSButtonHover1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonHover1ActionPerformed(evt);
            }
        });
        panel_main.add(rSButtonHover1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1230, 0, 50, 30));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 51, 0));
        jLabel14.setText("Book Id :");
        panel_main.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 240, 90, 40));

        txt_bookid.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 51, 0)));
        txt_bookid.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        txt_bookid.setPlaceholder("Enter Book Id");
        txt_bookid.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_bookidFocusLost(evt);
            }
        });
        panel_main.add(txt_bookid, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 240, 270, -1));

        txt_studentid.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 51, 0)));
        txt_studentid.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        txt_studentid.setPlaceholder("Enter Student Id");
        txt_studentid.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_studentidFocusLost(evt);
            }
        });
        panel_main.add(txt_studentid, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 330, 270, -1));

        jLabel20.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 51, 0));
        jLabel20.setText("Issue Date :");
        panel_main.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 430, 90, 40));

        jLabel21.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 51, 0));
        jLabel21.setText("Student Id :");
        panel_main.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 330, 90, 40));

        jLabel22.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 51, 0));
        jLabel22.setText("Due Date :");
        panel_main.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 520, 80, 40));

        rSMaterialButtonCircle1.setText("Issue Book");
        rSMaterialButtonCircle1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle1ActionPerformed(evt);
            }
        });
        panel_main.add(rSMaterialButtonCircle1, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 590, 280, 70));

        rSButtonHover2.setBackground(new java.awt.Color(102, 0, 153));
        rSButtonHover2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rSButtonHover2.setText("-");
        rSButtonHover2.setColorHover(new java.awt.Color(255, 0, 0));
        rSButtonHover2.setColorText(new java.awt.Color(0, 0, 0));
        rSButtonHover2.setFont(new java.awt.Font("Verdana", 1, 35)); // NOI18N
        rSButtonHover2.setInheritsPopupMenu(true);
        rSButtonHover2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSButtonHover2MouseClicked(evt);
            }
        });
        rSButtonHover2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonHover2ActionPerformed(evt);
            }
        });
        panel_main.add(rSButtonHover2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 0, 50, 30));

        date_due.setBackground(new java.awt.Color(255, 0, 51));
        date_due.setForeground(new java.awt.Color(255, 51, 0));
        panel_main.add(date_due, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 520, 260, 40));

        date_issue.setBackground(new java.awt.Color(255, 0, 51));
        date_issue.setForeground(new java.awt.Color(255, 51, 0));
        panel_main.add(date_issue, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 430, 270, 40));

        rSButtonHover3.setText("Clear All");
        rSButtonHover3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonHover3ActionPerformed(evt);
            }
        });
        panel_main.add(rSButtonHover3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 190, 100, -1));

        getContentPane().add(panel_main, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 730));

        setSize(new java.awt.Dimension(1283, 731));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        homepage hp = new homepage();
        hp.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel1MouseClicked

    private void rSButtonHover1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSButtonHover1MouseClicked
               int y_n = JOptionPane.showConfirmDialog(this,"Do you Want To Close ? ","WARNING",JOptionPane.YES_NO_OPTION);
        
        if(y_n ==JOptionPane.YES_OPTION){
        System.exit(0);
        
        }
    }//GEN-LAST:event_rSButtonHover1MouseClicked

    private void rSButtonHover1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonHover1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rSButtonHover1ActionPerformed

    private void txt_bookidFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_bookidFocusLost
        if(!txt_bookid.getText().equals("")){
        getbookdetails();    
        }
        else{
        lbl_bookid.setText("");
        lbl_bookname.setText("");
        lbl_authorname.setText("");
        lbl_quantity.setText("");
        
        }
    }//GEN-LAST:event_txt_bookidFocusLost

    private void txt_studentidFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_studentidFocusLost
                if(!txt_studentid.getText().equals("")){
                    getstudentdetails();   
        }
        else{
        lbl_studentid.setText("");
        lbl_studentname.setText("");
        lbl_roll.setText("");
        lbl_department.setText("");
        
        }
    }//GEN-LAST:event_txt_studentidFocusLost

    private void rSMaterialButtonCircle1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle1ActionPerformed
        if(lbl_quantity.getText().equals("0")){
        JOptionPane.showMessageDialog(this,"Book is not Available Now");
        
        
        }
        else{
        
                if(issuecheak()== false){
        
        if(issuebook()==true){
            
            JOptionPane.showMessageDialog(this,"Book Issued Successfully");
            
            updatebookcount();
        }
        else{
        
        JOptionPane.showMessageDialog(this,"Can't issue the Book ");
        }}
        else{
        JOptionPane.showMessageDialog(this,"This Student has allready issued this Book ");
        }
        
        
        }

    }//GEN-LAST:event_rSMaterialButtonCircle1ActionPerformed

    private void rSButtonHover2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSButtonHover2MouseClicked
        this.setExtendedState(issuebookdetails.ICONIFIED);
    }//GEN-LAST:event_rSButtonHover2MouseClicked

    private void rSButtonHover2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonHover2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rSButtonHover2ActionPerformed

    private void rSButtonHover3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonHover3ActionPerformed
        lbl_bookid.setText("");
        lbl_bookname.setText("");
        lbl_authorname.setText("");
        lbl_quantity.setText("");
        lbl_nullbookid.setText("");
        lbl_studentid.setText("");
        lbl_studentname.setText("");
        lbl_roll.setText("");
        lbl_department.setText("");
        lbl_nullstudentid.setText("");
        txt_bookid.setText("");
        txt_studentid.setText("");
        date_due.setCalendar(null);
    }//GEN-LAST:event_rSButtonHover3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(issuebooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(issuebooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(issuebooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(issuebooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new issuebooks().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser date_due;
    private com.toedter.calendar.JDateChooser date_issue;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JLabel lbl_authorname;
    private javax.swing.JLabel lbl_bookid;
    private javax.swing.JLabel lbl_bookname;
    private javax.swing.JLabel lbl_department;
    private javax.swing.JLabel lbl_nullbookid;
    private javax.swing.JLabel lbl_nullstudentid;
    private javax.swing.JLabel lbl_quantity;
    private javax.swing.JLabel lbl_roll;
    private javax.swing.JLabel lbl_studentid;
    private javax.swing.JLabel lbl_studentname;
    private javax.swing.JPanel panel_main;
    private rojeru_san.complementos.RSButtonHover rSButtonHover1;
    private rojeru_san.complementos.RSButtonHover rSButtonHover2;
    private rojeru_san.complementos.RSButtonHover rSButtonHover3;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle1;
    private app.bolivia.swing.JCTextField txt_bookid;
    private app.bolivia.swing.JCTextField txt_studentid;
    // End of variables declaration//GEN-END:variables
}
