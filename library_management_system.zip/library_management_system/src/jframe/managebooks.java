/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package jframe;








import java.awt.print.PrinterException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.*;
import java.text.MessageFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author MAHFUZUR RAHMAN
 */
public class managebooks extends javax.swing.JFrame {

    /**
     * Creates new form managebooks
     */
    public managebooks() {
        initComponents();
        
        setbookdetails();
    }
    
    
    //set data into the table
    
    String book_name,book_author;
    int book_id,book_quantity;
    DefaultTableModel model;
    
    public void setbookdetails(){
    
    try{
        
    Connection con = DBConnection.getConnection();
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery("select * from books_dtails");
    
    while(rs.next()){
        
        int bookid = rs.getInt("book_id");
        String bookname = rs.getString("book_name");
        String bookauthor = rs.getString("author_name");
        int bookquantity = rs.getInt("quantity");
        
        Object[] obj = {bookid,bookname,bookauthor,bookquantity};
        
        model = (DefaultTableModel)tbl_bookdetails.getModel();
        model.addRow(obj);
    }
    
    }catch(SQLException e){
    JOptionPane.showMessageDialog(null,e);
    }

    }

    
    //Add book details into database
    
    public boolean addbook(){
        boolean isadd = false;
        
    book_id = Integer.parseInt(txt_bookid.getText());
    book_name = txt_bookname.getText();
    book_author = txt_authorname.getText();
    book_quantity = Integer.parseInt(txt_quantity.getText());
    
    
    
    try{
    Connection con = DBConnection.getConnection();
    String sql = "insert into books_dtails values(?,?,?,?)";
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1, book_id);
    pst.setString(2, book_name);
    pst.setString(3, book_author);
    pst.setInt(4, book_quantity);
    
    int rowc = pst.executeUpdate();
    
    if(rowc > 0){
    
       isadd = true;  
    }
    else{
    isadd = false;
    }
    
    }catch(SQLException e){
    JOptionPane.showMessageDialog(null,e);
    }
    
    return isadd; 
    }
    
    
    
    //Update book into database
    
    
    public boolean updatebook(){
    
            boolean isupdated = false;
        
    book_id = Integer.parseInt(txt_bookid.getText());
    book_name = txt_bookname.getText();
    book_author = txt_authorname.getText();
    book_quantity = Integer.parseInt(txt_quantity.getText());
    
    try{
    
    
    Connection con = DBConnection.getConnection();
    String sql = "update books_dtails set book_name=?,author_name=?,quantity=? where book_id=? ";
    
    PreparedStatement pst = con.prepareStatement(sql);
    
    pst.setString(1, book_name);
    pst.setString(2, book_author);
    pst.setInt(3, book_quantity);
     pst.setInt(4, book_id);
     
     
     int rowc = pst.executeUpdate();
     
     if(rowc > 0){
     isupdated = true;
     }
     else{
     isupdated = false;
     }
    
    
    }catch(SQLException e){
    JOptionPane.showMessageDialog(null,e);
    
    }
    return isupdated;
    }
    
    
    
    //Delete book into Database
    
    public boolean deletebook(){
                boolean isdeleted = false;
        
    book_id = Integer.parseInt(txt_bookid.getText());
    
    try{
    
    Connection con = DBConnection.getConnection();
        String sql = "delete from books_dtails where book_id=? ";
    
    PreparedStatement pst = con.prepareStatement(sql);
    pst.setInt(1, book_id);
    
    int rowc = pst.executeUpdate();
    
    if(rowc > 0){
    isdeleted = true;
    
    }
    else{
    isdeleted = false;
    
    
    }
    
    
    }catch(SQLException e){
    JOptionPane.showMessageDialog(null,e);
    }
    
    
    return isdeleted;
    }
    
    //serach from database
    
    
    public void searchd(){
        
        try{
        
            Connection con = DBConnection.getConnection();
    String sql = "SELECT * FROM books_dtails where book_id=? ";
    PreparedStatement pst = con.prepareStatement(sql);
    int id = Integer.parseInt(txt_bookid.getText());
            pst.setInt(1, id);
             ResultSet rs = pst.executeQuery();
   
            if(rs.next()==true){
                String add1 = rs.getString("book_id");
                txt_bookid.setText(add1);
                String add2 = rs.getString("book_name");
                txt_bookname.setText(add2);
                String add3 = rs.getString("author_name");
                txt_authorname.setText(add3);
                String add4 = rs.getString("quantity");
                txt_quantity.setText(add4);

            }
            if(rs.next()==false)
            {
                JOptionPane.showInternalMessageDialog(this,"Please try again,Record Not Found");
            }
        
        }catch(NumberFormatException | SQLException e){
        JOptionPane.showMessageDialog(null,"Please Enter Book Id");
        }
        

    
    }
    
    //clear table 
    
    public void cleartbl(){
  DefaultTableModel model =   (DefaultTableModel)tbl_bookdetails.getModel();
    model.setRowCount(0);
    
    }
    
    
    
    
    //Record Print
    
    public void printrecord(){
    
    String h = "All Books Record";
    MessageFormat header = new MessageFormat(h);

    MessageFormat footer = new MessageFormat("S.M.Rahman Library Management System");
    
    try{
    
    tbl_bookdetails.print(JTable.PrintMode.FIT_WIDTH,header,footer);
    
    }catch(PrinterException e){
    JOptionPane.showMessageDialog(null,"Can Not Print"+e.getMessage());
    }
    
    
    
    }
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_bookid = new app.bolivia.swing.JCTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_bookname = new app.bolivia.swing.JCTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt_authorname = new app.bolivia.swing.JCTextField();
        txt_quantity = new app.bolivia.swing.JCTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnsearch = new rojerusan.RSMaterialButtonCircle();
        btnadd = new rojerusan.RSMaterialButtonCircle();
        btnupdate = new rojerusan.RSMaterialButtonCircle();
        btndelete = new rojerusan.RSMaterialButtonCircle();
        rSMaterialButtonCircle2 = new rojerusan.RSMaterialButtonCircle();
        jPanel3 = new javax.swing.JPanel();
        rSButtonHover1 = new rojeru_san.complementos.RSButtonHover();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_bookdetails = new rojeru_san.complementos.RSTableMetro();
        jLabel10 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        rSButtonHover2 = new rojeru_san.complementos.RSButtonHover();
        btn_print = new rojeru_san.complementos.RSButtonHover();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 102, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Rewind_48px.png"))); // NOI18N
        jLabel1.setText("Back");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 120, 50));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 120, 50));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Enter Book Id");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 140, 40));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Contact_26px.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 70, 50));

        txt_bookid.setBackground(new java.awt.Color(0, 102, 102));
        txt_bookid.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_bookid.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        txt_bookid.setPlaceholder("Enter Book Id");
        jPanel1.add(txt_bookid, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 130, 210, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Enter Book Name");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 140, 40));

        txt_bookname.setBackground(new java.awt.Color(0, 102, 102));
        txt_bookname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_bookname.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        txt_bookname.setPlaceholder("Enter Book Name");
        jPanel1.add(txt_bookname, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, 330, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Moleskine_26px.png"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 70, 50));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Collaborator_Male_26px.png"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 70, 50));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Author Name");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 350, 140, 40));

        txt_authorname.setBackground(new java.awt.Color(0, 102, 102));
        txt_authorname.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_authorname.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        txt_authorname.setPlaceholder("Author Name");
        jPanel1.add(txt_authorname, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 400, 330, -1));

        txt_quantity.setBackground(new java.awt.Color(0, 102, 102));
        txt_quantity.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        txt_quantity.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        txt_quantity.setPlaceholder("Quantity of book");
        jPanel1.add(txt_quantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 530, 330, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Unit_26px.png"))); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, 70, 50));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 0, 17)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Quantity");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 480, 140, 40));

        btnsearch.setBackground(new java.awt.Color(204, 204, 255));
        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });
        jPanel1.add(btnsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 120, -1, 60));

        btnadd.setText("ADD");
        btnadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaddActionPerformed(evt);
            }
        });
        jPanel1.add(btnadd, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 600, -1, 60));

        btnupdate.setText("UPDATE");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });
        jPanel1.add(btnupdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 600, -1, 60));

        btndelete.setText("DELETE");
        btndelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteActionPerformed(evt);
            }
        });
        jPanel1.add(btndelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 600, -1, 60));

        rSMaterialButtonCircle2.setBackground(new java.awt.Color(204, 0, 51));
        rSMaterialButtonCircle2.setText("CLEAR");
        rSMaterialButtonCircle2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSMaterialButtonCircle2ActionPerformed(evt);
            }
        });
        jPanel1.add(rSMaterialButtonCircle2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, -1, 60));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, 730));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rSButtonHover1.setBackground(new java.awt.Color(102, 0, 102));
        rSButtonHover1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rSButtonHover1.setText("-");
        rSButtonHover1.setColorHover(new java.awt.Color(255, 0, 0));
        rSButtonHover1.setColorText(new java.awt.Color(0, 0, 0));
        rSButtonHover1.setFont(new java.awt.Font("Verdana", 1, 35)); // NOI18N
        rSButtonHover1.setInheritsPopupMenu(true);
        rSButtonHover1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSButtonHover1MouseClicked(evt);
            }
        });
        rSButtonHover1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonHover1ActionPerformed(evt);
            }
        });
        jPanel3.add(rSButtonHover1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 0, 50, 30));

        tbl_bookdetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book Id", "Book Name", "Author Name", "Quantity"
            }
        ));
        tbl_bookdetails.setColorSelBackgound(new java.awt.Color(0, 102, 102));
        tbl_bookdetails.setFont(new java.awt.Font("Yu Gothic Light", 1, 25)); // NOI18N
        tbl_bookdetails.setFuenteFilas(new java.awt.Font("Times New Roman", 0, 15)); // NOI18N
        tbl_bookdetails.setFuenteFilasSelect(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        tbl_bookdetails.setFuenteHead(new java.awt.Font("Yu Gothic UI Semibold", 1, 25)); // NOI18N
        tbl_bookdetails.setRowHeight(35);
        tbl_bookdetails.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_bookdetailsMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_bookdetails);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 780, 330));

        jLabel10.setFont(new java.awt.Font("Verdana", 1, 30)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 0, 102));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Books_52px_1.png"))); // NOI18N
        jLabel10.setText("  Manage Books");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 30, 330, 60));

        jPanel4.setBackground(new java.awt.Color(255, 0, 102));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 370, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 100, 370, 5));

        rSButtonHover2.setBackground(new java.awt.Color(0, 102, 102));
        rSButtonHover2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rSButtonHover2.setText("X");
        rSButtonHover2.setColorHover(new java.awt.Color(255, 0, 0));
        rSButtonHover2.setColorText(new java.awt.Color(0, 0, 0));
        rSButtonHover2.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 25)); // NOI18N
        rSButtonHover2.setInheritsPopupMenu(true);
        rSButtonHover2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rSButtonHover2MouseClicked(evt);
            }
        });
        rSButtonHover2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonHover2ActionPerformed(evt);
            }
        });
        jPanel3.add(rSButtonHover2, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 0, 50, 30));

        btn_print.setBackground(new java.awt.Color(255, 0, 255));
        btn_print.setText("Print");
        btn_print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_printActionPerformed(evt);
            }
        });
        jPanel3.add(btn_print, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 130, 80, 30));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, 820, 730));

        setSize(new java.awt.Dimension(1283, 731));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        homepage hp = new homepage();
        hp.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel1MouseClicked

    private void rSButtonHover1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSButtonHover1MouseClicked
        
    }//GEN-LAST:event_rSButtonHover1MouseClicked

    private void rSButtonHover1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonHover1ActionPerformed
        this.setExtendedState(managebooks.ICONIFIED);
    }//GEN-LAST:event_rSButtonHover1ActionPerformed

    private void tbl_bookdetailsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_bookdetailsMouseClicked
        int rowm = tbl_bookdetails.getSelectedRow();
        TableModel model = tbl_bookdetails.getModel();
        
        txt_bookid.setText(model.getValueAt(rowm,0).toString());
        txt_bookname.setText(model.getValueAt(rowm,1).toString());
        txt_authorname.setText(model.getValueAt(rowm,2).toString());
        txt_quantity.setText(model.getValueAt(rowm,3).toString());
    }//GEN-LAST:event_tbl_bookdetailsMouseClicked

    private void btnaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaddActionPerformed
        if(addbook()==true){
        JOptionPane.showMessageDialog(this,"Book Added Successfully");
        cleartbl();
        setbookdetails();
        
        }
        else{
        JOptionPane.showMessageDialog(this,"Book Addition Failed");
        }
    }//GEN-LAST:event_btnaddActionPerformed

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
                if(updatebook()==true){
        JOptionPane.showMessageDialog(this,"Book Updated Successfully");
        cleartbl();
        setbookdetails();
        
        }
        else{
        JOptionPane.showMessageDialog(this,"Book Updation Failed");
        }
    }//GEN-LAST:event_btnupdateActionPerformed

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
searchd();
    }//GEN-LAST:event_btnsearchActionPerformed

    private void btndeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteActionPerformed
                        if(deletebook()==true){
        JOptionPane.showMessageDialog(this,"Book Deleted Successfully");
        cleartbl();
        setbookdetails();
        
        }
        else{
        JOptionPane.showMessageDialog(this,"Book Deletion Failed");
        }
    }//GEN-LAST:event_btndeleteActionPerformed

    private void rSMaterialButtonCircle2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSMaterialButtonCircle2ActionPerformed
        txt_bookid.setText("");
        txt_bookname.setText("");
        txt_authorname.setText("");
        txt_quantity.setText("");
    }//GEN-LAST:event_rSMaterialButtonCircle2ActionPerformed

    private void rSButtonHover2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rSButtonHover2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rSButtonHover2MouseClicked

    private void rSButtonHover2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonHover2ActionPerformed
              int y_n = JOptionPane.showConfirmDialog(this,"Do you Want To Close ? ","WARNING",JOptionPane.YES_NO_OPTION);
        
        if(y_n ==JOptionPane.YES_OPTION){
        System.exit(0);
        
        }
    }//GEN-LAST:event_rSButtonHover2ActionPerformed

    private void btn_printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_printActionPerformed
        printrecord();
    }//GEN-LAST:event_btn_printActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws IOException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(managebooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(managebooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(managebooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(managebooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new managebooks().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private rojeru_san.complementos.RSButtonHover btn_print;
    private rojerusan.RSMaterialButtonCircle btnadd;
    private rojerusan.RSMaterialButtonCircle btndelete;
    private rojerusan.RSMaterialButtonCircle btnsearch;
    private rojerusan.RSMaterialButtonCircle btnupdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane3;
    private rojeru_san.complementos.RSButtonHover rSButtonHover1;
    private rojeru_san.complementos.RSButtonHover rSButtonHover2;
    private rojerusan.RSMaterialButtonCircle rSMaterialButtonCircle2;
    private rojeru_san.complementos.RSTableMetro tbl_bookdetails;
    private app.bolivia.swing.JCTextField txt_authorname;
    private app.bolivia.swing.JCTextField txt_bookid;
    private app.bolivia.swing.JCTextField txt_bookname;
    private app.bolivia.swing.JCTextField txt_quantity;
    // End of variables declaration//GEN-END:variables
}
